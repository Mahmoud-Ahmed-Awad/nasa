import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FaGlobe, 
  FaSearch, 
  FaFilter, 
  FaChartLine,
  FaThermometerHalf,
  FaWeight,
  FaCalendarAlt,
  FaEye,
  FaDownload,
  FaShare
} from 'react-icons/fa';
import ExoplanetTable from '../components/ExoplanetTable';
import ChartComponent, { 
  ExoplanetTypeChart, 
  TemperatureChart, 
  MassComparisonChart, 
  DiscoveryMethodChart 
} from '../components/ChartComponent';
import MapComponent from '../components/MapComponent';

const Exoplanets = () => {
  const [exoplanets, setExoplanets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedChart, setSelectedChart] = useState('type');
  const [showMap, setShowMap] = useState(false);

  // Sample exoplanet data
  const sampleExoplanets = [
    {
      id: 1,
      name: "Kepler-452b",
      type: "Super Earth",
      mass: 5.0,
      radius: 1.6,
      temperature: 22,
      distance: 1402.5,
      discoveryYear: 2015,
      discoveryMethod: "Transit",
      star: "Kepler-452",
      orbitalPeriod: 384.8,
      semiMajorAxis: 1.046,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.83,
      description: "Kepler-452b is an exoplanet orbiting the Sun-like star Kepler-452 about 1,402 light-years from Earth. It is the first potentially rocky super-Earth planet discovered orbiting in the habitable zone of a star very similar to the Sun.",
      coordinates: [45.2, -89.3]
    },
    {
      id: 2,
      name: "Proxima Centauri b",
      type: "Terrestrial",
      mass: 1.27,
      radius: 1.1,
      temperature: -39,
      distance: 4.2,
      discoveryYear: 2016,
      discoveryMethod: "Radial Velocity",
      star: "Proxima Centauri",
      orbitalPeriod: 11.2,
      semiMajorAxis: 0.0485,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.87,
      description: "Proxima Centauri b is an exoplanet orbiting in the habitable zone of the red dwarf star Proxima Centauri, which is the closest star to the Sun and part of a triple star system.",
      coordinates: [-62.7, 17.5]
    },
    {
      id: 3,
      name: "TRAPPIST-1e",
      type: "Terrestrial",
      mass: 0.692,
      radius: 0.92,
      temperature: -28,
      distance: 39.6,
      discoveryYear: 2017,
      discoveryMethod: "Transit",
      star: "TRAPPIST-1",
      orbitalPeriod: 6.1,
      semiMajorAxis: 0.029,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.95,
      description: "TRAPPIST-1e is one of seven Earth-sized exoplanets orbiting the ultracool dwarf star TRAPPIST-1. It is considered one of the most promising candidates for habitability.",
      coordinates: [-5.5, 23.1]
    },
    {
      id: 4,
      name: "HD 209458 b",
      type: "Gas Giant",
      mass: 220.0,
      radius: 14.8,
      temperature: 1130,
      distance: 159.0,
      discoveryYear: 1999,
      discoveryMethod: "Transit",
      star: "HD 209458",
      orbitalPeriod: 3.5,
      semiMajorAxis: 0.047,
      eccentricity: 0.0,
      habitable: false,
      esiScore: 0.0,
      description: "HD 209458 b, also known as Osiris, is an exoplanet that orbits the Sun-like star HD 209458 in the constellation Pegasus. It was the first exoplanet to be discovered by the transit method.",
      coordinates: [18.8, 18.9]
    },
    {
      id: 5,
      name: "Gliese 581g",
      type: "Super Earth",
      mass: 3.1,
      radius: 1.3,
      temperature: -12,
      distance: 20.3,
      discoveryYear: 2010,
      discoveryMethod: "Radial Velocity",
      star: "Gliese 581",
      orbitalPeriod: 36.6,
      semiMajorAxis: 0.146,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.92,
      description: "Gliese 581g is an unconfirmed exoplanet in the Gliese 581 system. If confirmed, it would be the first Earth-like exoplanet found in the habitable zone of its star.",
      coordinates: [-7.7, 2.3]
    },
    {
      id: 6,
      name: "WASP-12b",
      type: "Gas Giant",
      mass: 470.0,
      radius: 18.0,
      temperature: 2250,
      distance: 1410.0,
      discoveryYear: 2008,
      discoveryMethod: "Transit",
      star: "WASP-12",
      orbitalPeriod: 1.1,
      semiMajorAxis: 0.023,
      eccentricity: 0.0,
      habitable: false,
      esiScore: 0.0,
      description: "WASP-12b is a hot Jupiter exoplanet that orbits the star WASP-12. It is one of the hottest known exoplanets and is being consumed by its star.",
      coordinates: [6.2, 29.7]
    },
    {
      id: 7,
      name: "Kepler-186f",
      type: "Terrestrial",
      mass: 1.4,
      radius: 1.1,
      temperature: -85,
      distance: 492.0,
      discoveryYear: 2014,
      discoveryMethod: "Transit",
      star: "Kepler-186",
      orbitalPeriod: 129.9,
      semiMajorAxis: 0.432,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.64,
      description: "Kepler-186f is the first Earth-size planet discovered in the habitable zone of another star. It orbits a red dwarf star and is located in the constellation Cygnus.",
      coordinates: [43.9, 44.9]
    },
    {
      id: 8,
      name: "55 Cancri e",
      type: "Super Earth",
      mass: 8.6,
      radius: 1.9,
      temperature: 2000,
      distance: 40.0,
      discoveryYear: 2004,
      discoveryMethod: "Radial Velocity",
      star: "55 Cancri",
      orbitalPeriod: 0.7,
      semiMajorAxis: 0.016,
      eccentricity: 0.0,
      habitable: false,
      esiScore: 0.0,
      description: "55 Cancri e is a super-Earth exoplanet that orbits the Sun-like star 55 Cancri. It is one of the densest known exoplanets and may be composed primarily of diamond.",
      coordinates: [28.7, 8.3]
    },
    {
      id: 9,
      name: "LHS 1140b",
      type: "Super Earth",
      mass: 6.6,
      radius: 1.4,
      temperature: -12,
      distance: 40.7,
      discoveryYear: 2017,
      discoveryMethod: "Transit",
      star: "LHS 1140",
      orbitalPeriod: 24.7,
      semiMajorAxis: 0.093,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.68,
      description: "LHS 1140b is a super-Earth exoplanet that orbits within the habitable zone of the red dwarf star LHS 1140. It is one of the most promising targets for atmospheric characterization.",
      coordinates: [-15.0, -2.5]
    },
    {
      id: 10,
      name: "K2-18b",
      type: "Super Earth",
      mass: 8.6,
      radius: 2.2,
      temperature: -23,
      distance: 124.0,
      discoveryYear: 2015,
      discoveryMethod: "Transit",
      star: "K2-18",
      orbitalPeriod: 32.9,
      semiMajorAxis: 0.159,
      eccentricity: 0.0,
      habitable: true,
      esiScore: 0.73,
      description: "K2-18b is a super-Earth exoplanet that orbits the red dwarf star K2-18. It is the first exoplanet where water vapor has been detected in its atmosphere.",
      coordinates: [11.3, 7.6]
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setExoplanets(sampleExoplanets);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const chartOptions = [
    { value: 'type', label: 'Type Distribution', component: ExoplanetTypeChart },
    { value: 'temperature', label: 'Temperature Analysis', component: TemperatureChart },
    { value: 'mass', label: 'Mass Comparison', component: MassComparisonChart },
    { value: 'discovery', label: 'Discovery Methods', component: DiscoveryMethodChart }
  ];

  const SelectedChartComponent = chartOptions.find(option => option.value === selectedChart)?.component;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-neon-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-neon-blue text-lg">Loading exoplanets...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-space font-bold text-gradient mb-4">
            Exoplanet Database
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore thousands of discovered exoplanets beyond our solar system. 
            Search, filter, and analyze data about these distant worlds.
          </p>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12"
        >
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-blue/20 rounded-xl p-6 text-center">
            <FaGlobe className="text-3xl text-neon-blue mx-auto mb-3" />
            <h3 className="text-2xl font-space font-bold text-gradient mb-1">
              {exoplanets.length}
            </h3>
            <p className="text-gray-300">Total Exoplanets</p>
          </div>
          
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-green/20 rounded-xl p-6 text-center">
            <FaThermometerHalf className="text-3xl text-neon-green mx-auto mb-3" />
            <h3 className="text-2xl font-space font-bold text-gradient mb-1">
              {exoplanets.filter(p => p.habitable).length}
            </h3>
            <p className="text-gray-300">Potentially Habitable</p>
          </div>
          
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-purple/20 rounded-xl p-6 text-center">
            <FaWeight className="text-3xl text-neon-purple mx-auto mb-3" />
            <h3 className="text-2xl font-space font-bold text-gradient mb-1">
              {exoplanets.filter(p => p.type === 'Terrestrial').length}
            </h3>
            <p className="text-gray-300">Terrestrial Planets</p>
          </div>
          
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-pink/20 rounded-xl p-6 text-center">
            <FaCalendarAlt className="text-3xl text-neon-pink mx-auto mb-3" />
            <h3 className="text-2xl font-space font-bold text-gradient mb-1">
              {new Set(exoplanets.map(p => p.discoveryYear)).size}
            </h3>
            <p className="text-gray-300">Discovery Years</p>
          </div>
        </motion.div>

        {/* Chart Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-blue/20 rounded-xl p-6">
            <div className="flex flex-col md:flex-row justify-between items-center mb-6">
              <h2 className="text-2xl font-space font-bold text-gradient mb-4 md:mb-0">
                Data Analysis
              </h2>
              <div className="flex flex-wrap gap-2">
                {chartOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setSelectedChart(option.value)}
                    className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                      selectedChart === option.value
                        ? 'bg-neon-blue/20 border border-neon-blue/30 text-neon-blue'
                        : 'bg-space-gray/50 border border-neon-blue/20 text-gray-400 hover:text-neon-blue'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
            
            {SelectedChartComponent && (
              <SelectedChartComponent exoplanets={exoplanets} />
            )}
          </div>
        </motion.div>

        {/* Map Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mb-12"
        >
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-blue/20 rounded-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-space font-bold text-gradient">
                Exoplanet Locations
              </h2>
              <button
                onClick={() => setShowMap(!showMap)}
                className="btn-neon text-sm py-2 px-4 flex items-center space-x-2"
              >
                <FaEye />
                <span>{showMap ? 'Hide Map' : 'Show Map'}</span>
              </button>
            </div>
            
            {showMap && (
              <MapComponent
                type="exoplanets"
                data={exoplanets}
                title="Exoplanet Discovery Locations"
                height={400}
              />
            )}
          </div>
        </motion.div>

        {/* Exoplanet Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <ExoplanetTable exoplanets={exoplanets} />
        </motion.div>

        {/* Export Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="bg-space-gray/30 backdrop-blur-sm border border-neon-blue/20 rounded-xl p-6">
            <h3 className="text-xl font-space font-bold text-gradient mb-4">
              Export Data
            </h3>
            <p className="text-gray-300 mb-6">
              Download exoplanet data in various formats for your research and analysis.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-neon text-sm py-2 px-6 flex items-center space-x-2">
                <FaDownload />
                <span>Download CSV</span>
              </button>
              <button className="px-6 py-2 bg-neon-purple/20 hover:bg-neon-purple/30 border border-neon-purple/30 rounded-lg text-neon-purple hover:text-white transition-all duration-300 flex items-center space-x-2">
                <FaShare />
                <span>Share Data</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Exoplanets;

